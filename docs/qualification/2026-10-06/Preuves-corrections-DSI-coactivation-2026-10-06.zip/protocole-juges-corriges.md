# Liaison des juges indépendants — candidat corrigé

L’outil `lie_jugements_corriges.py` reste hors runtime et ne remplace pas
`lie_jugements.py`. Il utilise le contrat atomique de
`Collectivite-corrections-pr5/scripts/coactivation_assessment.py`.

## Export avant création du juge

Depuis la racine du workspace, pour chaque réponse terminée et après contrôle
du gel avec le vérificateur du candidat corrigé :

```powershell
$pythonJugements = 'C:\Users\Krn\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$env:PYTHONUTF8 = '1'
& $pythonJugements .\lie_jugements_corriges.py export --candidate .\Collectivite-corrections-pr5 --response .\Collectivite-corrections-pr5\tests\evidence\coactivation-corrigee\campagne\plugin-dsi-reversibilite.jsonl --destination .\juges-corriges\plugin-dsi-reversibilite
```

Adapter uniquement le nom du cas et le dossier réel des réponses. L’export
produit `.packet.json`, `.prompt.md` et `.export.json` ; il réserve le nom
`.jugement.json` sans écrire de jugement. Tout fichier déjà présent bloque
l’export. `export_packet(candidate, response, destination)` expose la même
fonction pour un orchestrateur Python.

Créer **ensuite** un nouveau sous-agent, avec un nom unique par cas et
`fork_turns="none"`. Son message est le contenu intégral du `.prompt.md`.
Ne réutiliser ni un agent d’implémentation ni une session d’un ancien juge.
Ne lui transmettre ni runtime, ni ancienne mesure, ni interprétation du
répondant ou du coordinateur.

## Protocole exact du juge

Le `.prompt.md` contient l’appel exact de lecture à copier : un
`functions.exec` contenant seulement `text(await tools.exec_command({...}));`.
Les arguments sont du JSON à clés entre guillemets. Le résultat doit contenir
le paquet complet ; une troncature ne peut être compensée par une évaluation
du fragment. Aucun autre fichier, recherche externe ou outil n’est autorisé.

Le jugement contient exactement les quatre clés racine :

```json
{
  "case_id": "identifiant_du_paquet",
  "trace_sha256": "valeur_trace_sha256_du_paquet",
  "verdict": "reussite|echec|bloque",
  "invariants": {
    "identifiant_atomique_exact": {
      "status": null,
      "basis": "missing",
      "evidence_refs": [],
      "rationale": "Pièce absente ou justification précise."
    }
  }
}
```

`status` accepte exclusivement `true`, `false` ou `null`. `basis` accepte
`observation`, `retrieval`, `abstention` ou `missing`. Les références sont les
`event_id` réellement capturés. Tous les invariants du paquet sont requis.
Le barème détermine leur appréciation et le verdict ; cet exemple est un
schéma de format, sans valeur de jugement.

Écrire une seule fois le JSON complet dans le chemin absolu indiqué par le
prompt, par **un seul** appel `functions.exec` contenant exactement :

```javascript
text(await tools.apply_patch("*** Begin Patch\n*** Add File: <chemin absolu indiqué>\n+{\n+  <JSON complet, chaque ligne précédée de +>\n+}\n*** End Patch"));
```

La chaîne doit être un littéral JSON correctement échappé. Aucun nom de
variable, code additionnel, contrôle shell, suffixe, deuxième fichier,
mise à jour ou seconde écriture. Le juge termine ensuite sa tâche.

## Liaison et appréciation après achèvement

Après `task_complete`, retrouver la session native du juge par sa métadonnée
`session_meta.source.subagent.thread_spawn.agent_path`, jamais par une
affirmation contenue dans son jugement. Fournir également la trace native du
parent ayant réellement créé le juge :

```powershell
& $pythonJugements .\lie_jugements_corriges.py bind --candidate .\Collectivite-corrections-pr5 --response .\Collectivite-corrections-pr5\tests\evidence\coactivation-corrigee\campagne\plugin-dsi-reversibilite.jsonl --packet .\juges-corriges\plugin-dsi-reversibilite\plugin-dsi-reversibilite.packet.json --judgment .\juges-corriges\plugin-dsi-reversibilite\plugin-dsi-reversibilite.jugement.json --native-session '<rollout natif du nouveau juge>' --parent-session 'C:\Users\Krn\.codex\sessions\2026\10\06\rollout-2026-10-06T10-04-24-01a1103e-0b49-70c1-8f4e-66a36b54916f.jsonl' --agent /root/juge_corrige_01 --parent-id 01a1103e-0b49-70c1-8f4e-66a36b54916f --destination .\juges-corriges\plugin-dsi-reversibilite\liaison
```

`bind` reconstruit le paquet et applique `validate_judgment` : il apprécie
mécaniquement le contrat, les références, le STOP observé et le verdict,
sans refaire le jugement métier. Il compare **tout** le JSON émis au fichier,
puis produit `trace-juge.jsonl` et `execution-juge.json` dans `liaison`.
Cette dernière pièce contient l’appréciation recalculée, les empreintes de
la réponse, du paquet, du jugement et du binder, l’identité native, le modèle,
les appels de lecture/écriture et la preuve de spawn sans historique.

Les traces natives sont lues sans être exécutées. Leur export exclut les
instructions système, le raisonnement, les identifiants de compte et le
message chiffré de création. Ces preuves locales ne sont pas signées par le
fournisseur. Elles démontrent une liaison observable ; elles ne certifient
ni la justesse du jugement ni une validation juridique humaine.

Le binder exige une session créée après l’export, un seul tour achevé,
la lecture intégrale du seul paquet et l’écriture unique attestée. Un juge
qui dévie de ce protocole n’est pas relié par une exception ad hoc. Préserver
sa production et qualifier cette liaison comme bloquée ; ne pas la réécrire.

Les résultats restent distincts du gel : si le vérificateur du candidat doit
lire des `.jugement.json` à côté des réponses, publier une copie seulement
après cette liaison, en conservant le même SHA et l’original. Le vérificateur
seul indique encore `judge_identity_checked=false` ; l’identité est démontrée
par la pièce `execution-juge.json`. `release_ready=false` reste obligatoire.

Tests du binder :

```powershell
& $pythonJugements -m unittest test_lie_jugements_corriges -v
```
