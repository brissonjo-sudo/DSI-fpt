"""Campagne autonome r2 neuve, runtime pin 704e5dd, sans transfert de scores."""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from lie_jugements_corriges import BindingError, _arguments, _canonical, _events, _json, _output, _read_command, _sha, _write, native_proof
import lie_jugements_corriges as native_module

BASE = Path(__file__).resolve().parent
CANDIDATE = BASE / 'DSI-corrections-pr5'
RUN = BASE / 'qualification-dsi-0.2.1-native-r2'
PIN = '704e5dd6a3d15994ed431b23585aabd72086ca75'
PARENT_ID = '01a112c3-9b24-7453-a0a9-bdda459d77c3'
SESSIONS = Path('C:/Users/Krn/.codex/sessions/2026/10/06')

def git(*args: str) -> bytes:
    return subprocess.run(['git', '-c', f'safe.directory={CANDIDATE.as_posix()}', '-C', str(CANDIDATE), *args], capture_output=True, check=True).stdout

def session(agent: str) -> Path:
    matches = []
    for path in SESSIONS.glob('*.jsonl'):
        with path.open(encoding='utf-8') as stream:
            meta = _json(stream.readline()).get('payload', {})
        source = meta.get('source', {})
        if isinstance(source, dict) and source.get('subagent', {}).get('thread_spawn', {}).get('agent_path') == agent:
            matches.append(path)
    if len(matches) != 1:
        raise BindingError(f'Session ambiguë {agent}: {len(matches)}')
    return matches[0]

def parent_session() -> Path:
    matches = list(SESSIONS.glob('*' + PARENT_ID + '.jsonl'))
    if len(matches) != 1:
        raise BindingError('Session parent absente')
    return matches[0]

def retain_spawn(agent: str, role: str, directory: Path) -> None:
    parent = _events(parent_session())
    calls = [v for v in parent if v.get('payload', {}).get('type') == 'function_call' and v['payload'].get('name') == 'spawn_agent' and _json(v['payload']['arguments']).get('task_name') == agent.rsplit('/', 1)[-1]]
    if len(calls) != 1:
        raise BindingError('Spawn à conserver ambigu')
    call = calls[0]
    args = _json(call['payload']['arguments'])
    if args.get('fork_turns') != 'none' or 'model' in args or 'reasoning_effort' in args:
        raise BindingError('Spawn frais sans override requis')
    returns = [v for v in parent if v.get('payload', {}).get('type') == 'function_call_output' and v['payload'].get('call_id') == call['payload']['call_id']]
    if len(returns) != 1 or _json(returns[0]['payload']['output']).get('task_name') != agent:
        raise BindingError('Retour spawn divergent')
    safe_args = {key: value for key, value in args.items() if key in ('task_name', 'fork_turns', 'model', 'reasoning_effort')}
    message_hash = hashlib.sha256(_canonical(args.get('message')).encode('utf-8')).hexdigest()
    _write(directory / 'liaison' / ('spawn-' + role + '.json'), json.dumps({'parent_thread_id': PARENT_ID, 'timestamp': call['timestamp'], 'call_id': call['payload']['call_id'], 'arguments': safe_args, 'initial_message_sha256': message_hash, 'initial_message_verified': False, 'result_timestamp': returns[0]['timestamp'], 'result': _json(returns[0]['payload']['output'])}, ensure_ascii=False, indent=2) + '\n')

def prepare() -> None:
    sys.path.insert(0, str(CANDIDATE / 'scripts'))
    import eval_suite
    parent = _events(parent_session())
    models = {v['payload']['model'] for v in parent if v['type'] == 'turn_context'}
    if len(models) != 1:
        raise BindingError('Modèle natif parent absent ou ambigu')
    model = next(iter(models))
    if git('rev-parse', 'HEAD').decode().strip() != PIN:
        raise BindingError('HEAD candidat divergent')
    eval_suite.prepare_run(RUN, model, model)
    manifest = _json((RUN / 'manifest.json').read_text(encoding='utf-8'))
    if len(manifest['runtime_sha256']) != 30:
        raise BindingError('Runtime différent de 30 fichiers')
    for relative, digest in manifest['runtime_sha256'].items():
        if hashlib.sha256(git('show', PIN + ':' + relative)).hexdigest() != digest:
            raise BindingError('Runtime courant différent du pin ' + relative)
    for relative in ('tests/cas-de-test.json', 'tests/bareme-cas-de-test.md'):
        if git('show', PIN + ':' + relative) != (CANDIDATE / relative).read_bytes():
            raise BindingError('Suite/barème divergent du pin')
    manifest.update(source_commit=PIN, parent_thread_id=PARENT_ID, model_metadata_source=parent_session().name, release_ready=False, publication_ready=False, evaluation_scope='Codex natif sans consultation extérieure ni source primaire; contextes frais pour chaque rôle et chaque cas', respondent_scope_rule='Lire SKILL.md en premier, puis seulement les fichiers utiles réellement livrés dans la liste des 30 chemins; aucune lecture hors liste, aucun fichier absent reconstitué.', runtime_path_inventory=sorted(manifest['runtime_sha256']))
    (RUN / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    for case in eval_suite.load_cases(RUN / 'suite.json'):
        directory = RUN / case['id']
        for relative in manifest['runtime_sha256']:
            target = directory / 'runtime' / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(git('show', PIN + ':' + relative))
        created = datetime.now(timezone.utc).isoformat()
        _write(directory / 'responder.export.json', json.dumps({'created_at': created, 'runtime_sha256': manifest['runtime_sha256'], 'question_sha256': _sha(directory / 'prompt.md')}, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'prepared': 28, 'model': model, 'runtime_files': 30, 'source_commit': PIN}, ensure_ascii=False))

def export(case_id: str) -> None:
    directory = RUN / case_id
    case = next(c for c in _json((RUN / 'suite.json').read_text(encoding='utf-8')) if c['id'] == case_id)
    packet = {'case_id': case_id, 'prompt': case['prompt'], 'response': (directory / 'response.md').read_text(encoding='utf-8'), 'attendus': case['attendus'], 'rubric': (RUN / 'bareme.md').read_text(encoding='utf-8'), 'response_sha256': _sha(directory / 'response.md')}
    _write(directory / 'judge.packet.json', json.dumps(packet, ensure_ascii=False, indent=2) + '\n')
    _write(directory / 'judge.export.json', json.dumps({'exported_at': datetime.now(timezone.utc).isoformat(), 'packet_sha256': _sha(directory / 'judge.packet.json'), 'response_sha256': packet['response_sha256']}, ensure_ascii=False, indent=2) + '\n')
    print(case_id + ' exporté')

def filtered(native: list[dict]) -> list[dict]:
    kept = []
    for item in native:
        payload = item.get('payload', {})
        if item['type'] == 'session_meta':
            selected = {k: payload[k] for k in ('id', 'timestamp', 'agent_path') if k in payload}
            selected['source'] = {'subagent': {'thread_spawn': payload.get('source', {}).get('subagent', {}).get('thread_spawn', {})}}
        elif item['type'] == 'turn_context':
            selected = {k: payload[k] for k in ('turn_id', 'model')}
        elif payload.get('type') in ('custom_tool_call', 'custom_tool_call_output', 'function_call', 'function_call_output'):
            selected = {k: v for k, v in payload.items() if k in ('type', 'call_id', 'name', 'input', 'arguments', 'output')}
        elif payload.get('type') in ('task_started', 'task_complete'):
            selected = {k: v for k, v in payload.items() if k in ('type', 'turn_id', 'started_at', 'completed_at')}
        else:
            continue
        kept.append({'timestamp': item['timestamp'], 'type': item['type'], 'payload': selected})
    return kept

def bind_responder(case_id: str, agent: str) -> None:
    directory = RUN / case_id
    native_path = session(agent)
    native = _events(native_path)
    parent = _events(parent_session())
    meta = native[0]['payload']
    spawn = meta['source']['subagent']['thread_spawn']
    if spawn['parent_thread_id'] != PARENT_ID or spawn['agent_path'] != agent:
        raise BindingError('Identité répondant divergente')
    calls_parent = [v for v in parent if v.get('payload', {}).get('type') == 'function_call' and v['payload'].get('name') == 'spawn_agent' and _json(v['payload']['arguments']).get('task_name') == agent.rsplit('/', 1)[-1]]
    if len(calls_parent) != 1 or _json(calls_parent[0]['payload']['arguments']).get('fork_turns') != 'none':
        raise BindingError('Spawn répondant frais absent')
    if 'model' in _json(calls_parent[0]['payload']['arguments']):
        raise BindingError('Override modèle répondant interdit')
    spawn_event = calls_parent[0]
    returned = [v for v in parent if v.get('payload', {}).get('type') == 'function_call_output' and v['payload'].get('call_id') == spawn_event['payload']['call_id']]
    if len(returned) != 1 or _json(returned[0]['payload']['output']).get('task_name') != agent:
        raise BindingError('Retour spawn répondant non lié')
    created = _json((directory / 'responder.export.json').read_text(encoding='utf-8'))['created_at']
    def moment(value): return datetime.fromisoformat(value.replace('Z', '+00:00'))
    if not moment(created) <= moment(spawn_event['timestamp']) <= moment(meta['timestamp']) <= moment(returned[0]['timestamp']):
        raise BindingError('Chronologie répondant divergente')
    started = [v for v in native if v.get('payload', {}).get('type') == 'task_started']
    ended = [v for v in native if v.get('payload', {}).get('type') == 'task_complete']
    models = {v['payload']['model'] for v in native if v['type'] == 'turn_context'}
    if len(started) != 1 or len(ended) != 1 or len(models) != 1 or started[0]['payload']['turn_id'] != ended[0]['payload']['turn_id']:
        raise BindingError('Répondant non achevé ou réutilisé')
    start_index, end_index = native.index(started[0]), native.index(ended[0])
    if start_index >= end_index or any(v['payload']['turn_id'] != started[0]['payload']['turn_id'] for v in native if v['type'] == 'turn_context'):
        raise BindingError('Contexte répondant réutilisé')
    allowed = _json((RUN / 'manifest.json').read_text(encoding='utf-8'))['runtime_sha256']
    export = _json((directory / 'responder.export.json').read_text(encoding='utf-8'))
    frozen_case = next(case for case in _json((RUN / 'suite.json').read_text(encoding='utf-8')) if case['id'] == case_id)
    question_path = directory / 'prompt.md'
    if _sha(question_path) != export['question_sha256'] or question_path.read_text(encoding='utf-8') != frozen_case['prompt'] + '\n':
        raise BindingError('Question figée altérée')
    read_paths = []
    write_count = 0
    question_call_id = None
    for item in native:
        p = item.get('payload', {})
        if p.get('type') not in ('custom_tool_call', 'function_call'):
            continue
        if p.get('name') != 'exec':
            raise BindingError('Outil répondant hors protocole')
        if not start_index < native.index(item) < end_index:
            raise BindingError('Appel répondant hors exécution fraîche')
        script = p.get('input', p.get('arguments'))
        outputs = [v for v in native if v.get('payload', {}).get('call_id') == p['call_id'] and v['payload'].get('type') in ('custom_tool_call_output', 'function_call_output')]
        if len(outputs) != 1:
            raise BindingError('Résultat répondant absent')
        parts = _output(outputs[0]['payload'])
        if len(parts) != 2 or not parts[0].startswith('Script completed\n'):
            raise BindingError('Appel répondant multiple ou incomplet')
        if 'tools.apply_patch(' in script:
            if question_call_id is None:
                raise BindingError('Question non lue avant réponse')
            patch = _arguments(script, 'apply_patch')
            lines = patch.splitlines()
            if lines[0] != '*** Begin Patch' or lines[1].replace('\\', '/').casefold() != ('*** Add File: ' + (directory / 'response.md').as_posix()).casefold() or lines[-1] != '*** End Patch' or any(not x.startswith('+') for x in lines[2:-1]):
                raise BindingError('Patch réponse divergent')
            written = '\n'.join(x[1:] for x in lines[2:-1]) + '\n'
            if written != (directory / 'response.md').read_text(encoding='utf-8') or _json(parts[1]) != {}:
                raise BindingError('Réponse finale différente du patch réellement écrit')
            write_count += 1
        else:
            args = _arguments(script, 'exec_command')
            matched = re.fullmatch(r"Get-Content -LiteralPath '([^']+)' -Raw", args['cmd'])
            if not matched or set(args) != {'cmd', 'max_output_tokens'}:
                raise BindingError('Lecture répondant hors grammaire')
            path = Path(matched[1]).resolve()
            result = _json(parts[1])
            if write_count:
                raise BindingError('Lecture après écriture de réponse')
            if path == question_path:
                if question_call_id is not None or read_paths != ['SKILL.md']:
                    raise BindingError('Question requise une fois immédiatement après SKILL')
                if result.get('exit_code') != 0 or result.get('output', '').rstrip('\r\n') != question_path.read_text(encoding='utf-8').rstrip('\r\n'):
                    raise BindingError('Lecture question tronquée ou échouée')
                question_call_id = p['call_id']
                continue
            try:
                relative = path.relative_to(directory / 'runtime').as_posix()
            except ValueError:
                raise BindingError('Lecture hors runtime isolé')
            if relative not in allowed or _sha(path) != allowed[relative]:
                raise BindingError('Lecture runtime non autorisée ou modifiée')
            if read_paths and question_call_id is None:
                raise BindingError('Question requise avant les références runtime')
            if result.get('exit_code') != 0 or result.get('output', '').rstrip('\r\n') != path.read_text(encoding='utf-8').rstrip('\r\n'):
                raise BindingError('Lecture runtime tronquée ou échouée')
            read_paths.append(relative)
    if not read_paths or read_paths[0] != 'SKILL.md' or write_count != 1 or question_call_id is None:
        raise BindingError('Chargement SKILL ou écriture unique absente')
    trace = directory / 'liaison' / 'trace-repondant.jsonl'
    _write(trace, ''.join(json.dumps(v, ensure_ascii=False) + '\n' for v in filtered(native)))
    proof = {'agent': agent, 'session_id': meta['id'], 'parent_thread_id': PARENT_ID, 'models': sorted(models), 'fork_turns': 'none', 'completed': True, 'read_runtime_files': read_paths, 'runtime_only_reads': True, 'skill_read_first': True, 'response_patch_comparison': 'exact_text', 'response_sha256': _sha(directory / 'response.md'), 'trace_sha256': _sha(trace), 'native_session_file': native_path.name, 'source_commit': PIN, 'release_ready': False, 'spawn_call_id': spawn_event['payload']['call_id'], 'spawn_timestamp': spawn_event['timestamp'], 'turn_id': started[0]['payload']['turn_id'], 'binder_sha256': _sha(Path(__file__))}
    proof.update(runtime_only_reads=False, runtime_and_single_question_reads_only=True, question_file_read_verified=True, question_sha256=_sha(question_path), question_read_call_id=question_call_id, initial_message_verified=False)
    _write(directory / 'liaison' / 'execution-repondant.json', json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
    retain_spawn(agent, 'repondant', directory)
    print(case_id + ' répondant lié')

def bind_judge(case_id: str, agent: str) -> None:
    directory = RUN / case_id
    export_manifest = _json((directory / 'judge.export.json').read_text(encoding='utf-8'))
    judgment = _json((directory / 'judgment.json').read_text(encoding='utf-8'))
    if set(judgment) != {'verdict', 'notes', 'response_sha256'} or judgment['response_sha256'] != _sha(directory / 'response.md') or judgment['verdict'] not in {'RÉUSSITE', 'DEMI-RÉUSSITE', 'ÉCHEC'} or not judgment['notes'].strip():
        raise BindingError('Jugement invalide')
    if export_manifest['packet_sha256'] != _sha(directory / 'judge.packet.json'):
        raise BindingError('Paquet juge altéré')
    native_path = session(agent)
    # Même preuve native et même grammaire fermée; seule la graphie absolue
    # du chemin devient portable pour éviter les échappements JavaScript.
    original_read_command = native_module._read_command
    native_module._read_command = lambda path: "Get-Content -LiteralPath '" + path.resolve().as_posix().replace("'", "''") + "' -Raw"
    try:
        proof, events = native_proof(_events(native_path), _events(parent_session()), agent, PARENT_ID, directory / 'judge.packet.json', directory / 'judgment.json', export_manifest['exported_at'])
    finally:
        native_module._read_command = original_read_command
    trace = directory / 'liaison' / 'trace-juge.jsonl'
    _write(trace, ''.join(json.dumps(v, ensure_ascii=False) + '\n' for v in events))
    proof.update(case_id=case_id, native_session_file=native_path.name, response_sha256=_sha(directory / 'response.md'), judgment_sha256=_sha(directory / 'judgment.json'), source_commit=PIN, trace_sha256=_sha(trace), release_ready=False, exact_read_path_format='absolute_posix', binder_sha256=_sha(Path(__file__)), native_proof_module_sha256=_sha(Path(native_module.__file__)))
    _write(directory / 'liaison' / 'execution-juge.json', json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
    retain_spawn(agent, 'juge', directory)
    print(case_id + ' juge lié : ' + judgment['verdict'])

def summarize() -> None:
    sys.path.insert(0, str(CANDIDATE / 'scripts'))
    import eval_suite
    totals = eval_suite.validate_run(RUN)
    eval_suite.write_summary(RUN, totals)
    manifest = _json((RUN / 'manifest.json').read_text(encoding='utf-8'))
    records = []
    retained_agents = set()
    for case in eval_suite.load_cases(RUN / 'suite.json'):
        directory = RUN / case['id']
        for role in ('repondant', 'juge'):
            proof = _json((directory / 'liaison' / f'execution-{role}.json').read_text(encoding='utf-8'))
            retained_agents.add(proof['agent'])
            if proof['response_sha256'] != _sha(directory / 'response.md') or proof['source_commit'] != PIN:
                raise BindingError('Preuve divergente ' + case['id'])
            if proof['models'] != [manifest['responder']] or proof['trace_sha256'] != _sha(directory / 'liaison' / f'trace-{role}.jsonl'):
                raise BindingError('Modèle ou trace divergents ' + case['id'])
            if role == 'repondant' and (proof.get('question_file_read_verified') is not True or proof.get('question_sha256') != _sha(directory / 'prompt.md') or proof.get('initial_message_verified') is not False):
                raise BindingError('Preuve observable de question absente ' + case['id'])
            if not (directory / 'liaison' / ('spawn-' + role + '.json')).is_file():
                retain_spawn(proof['agent'], role, directory)
        judgment = _json((directory / 'judgment.json').read_text(encoding='utf-8'))
        records.append({'case_id': case['id'], 'verdict': judgment['verdict'], 'notes': judgment['notes'], 'response_sha256': judgment['response_sha256']})
    parent_events = _events(parent_session())
    parent_calls = [v for v in parent_events if v.get('payload', {}).get('type') == 'function_call' and v['payload'].get('name') == 'spawn_agent' and '/root/campagne_dsi_native_021/' + _json(v['payload']['arguments']).get('task_name', '') in retained_agents]
    if len(retained_agents) != 56 or len(parent_calls) != 56:
        raise BindingError('Les 56 créations retenues ne sont pas démontrées')
    retained_call_ids = {v['payload']['call_id'] for v in parent_calls}
    parent_trace = [{'timestamp': parent_events[0]['timestamp'], 'type': 'session_meta', 'payload': {'id': PARENT_ID, 'timestamp': parent_events[0]['payload']['timestamp']}}]
    for event in parent_events:
        payload = event.get('payload', {})
        if payload.get('call_id') in retained_call_ids and payload.get('type') in ('function_call', 'function_call_output'):
            safe_payload = {key: value for key, value in payload.items() if key in ('type', 'name', 'call_id', 'arguments', 'output')}
            if payload.get('type') == 'function_call':
                raw_args = _json(payload['arguments'])
                safe_payload['arguments'] = _canonical({key: value for key, value in raw_args.items() if key in ('task_name', 'fork_turns', 'model', 'reasoning_effort')})
            parent_trace.append({'timestamp': event['timestamp'], 'type': event['type'], 'payload': safe_payload})
    if len(parent_trace) != 113:
        raise BindingError('Trace parent incomplète')
    _write(RUN / 'trace-parent-filtre.jsonl', ''.join(json.dumps(v, ensure_ascii=False) + '\n' for v in parent_trace))
    summary = _json((RUN / 'summary.json').read_text(encoding='utf-8'))
    summary.update(source_commit=PIN, models={'respondant': manifest['responder'], 'juge': manifest['judge']}, native_proofs_complete=28, release_ready=False, evaluation_scope=manifest['evaluation_scope'], parent_trace_sha256=_sha(RUN / 'trace-parent-filtre.jsonl'), retained_fresh_roles=56)
    total_calls = [v for v in parent_events if v.get('payload', {}).get('type') == 'function_call' and v['payload'].get('name') == 'spawn_agent' and re.fullmatch(r'[rj]2\d{2}[a-z]?', _json(v['payload']['arguments']).get('task_name', ''))]
    created_calls = []
    launch_failures = []
    for call in total_calls:
        returns = [v for v in parent_events if v.get('payload', {}).get('type') == 'function_call_output' and v['payload'].get('call_id') == call['payload']['call_id']]
        if len(returns) != 1:
            raise BindingError('Retour lancement absent ou ambigu')
        raw = returns[0]['payload']['output']
        try:
            returned = _json(raw)
        except (ValueError, TypeError):
            returned = {}
        expected = '/root/campagne_dsi_native_021/' + _json(call['payload']['arguments'])['task_name']
        if isinstance(returned, dict) and returned.get('task_name') == expected:
            created_calls.append(call)
        else:
            launch_failures.append({'timestamp': call['timestamp'], 'task_name': _json(call['payload']['arguments'])['task_name'], 'call_id': call['payload']['call_id'], 'output': raw, 'role_created': False})
    rejected_path = RUN / 'tentatives-rejetees.json'
    rejected = _json(rejected_path.read_text(encoding='utf-8')) if rejected_path.is_file() else []
    if len(created_calls) != 56 + len(rejected):
        raise BindingError('Nombre de rôles créés incohérent avec les tentatives rejetées')
    summary.update(created_fresh_roles_total=len(created_calls), failed_launches=launch_failures, rejected_protocol_attempts=len(rejected), rejected_attempts=rejected, uniform_input_constraint=manifest['respondent_scope_rule'], runtime_path_inventory=manifest['runtime_path_inventory'], historical_scores_transferred=False, question_file_reads_verified=28, initial_messages_verified=False)
    (RUN / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    _write(RUN / 'rapport-28-cas.json', json.dumps(records, ensure_ascii=False, indent=2) + '\n')
    rows = ['# Évaluation DSI 0.2.1 — campagne native r2', '', f'Commit source : `{PIN}`. Modèle natif : `{manifest["responder"]}`. Runtime isolé : 30 fichiers par répondant. Suite et barème figés.', '', f'Totaux retenus : {totals}. Seuil autonome : {summary["threshold_passed"]}. Échecs critiques : {summary["critical_failures"]}.', '', f'{len(created_calls)} rôles frais créés au total; 56 rôles retenus avec preuve. {len(rejected)} tentative(s) exécutée(s) rejetée(s), conservée(s) séparément et exclue(s) des verdicts retenus. {len(launch_failures)} lancement(s) refusé(s), sans rôle créé, consignés dans la synthèse.', '', 'Tous les répondants ont reçu dès leur création la même règle de périmètre et la liste des 30 chemins livrés, sans attendu, barème, ancien résultat ni indice métier. Aucun score historique transféré. Le runtime est celui du commit source et n’a pas été modifié pendant cette campagne.', '', 'Portée : contextes Codex frais sans consultation extérieure ni source primaire; les réponses et jugements ne qualifient pas le retrieval juridique, le plugin, un autre modèle ou une exécution métier. release_ready=false ; publication_ready=false.', '', '| Cas | Verdict | Réponse | Jugement | Preuves |', '|---|---|---|---|---|']
    for record in records:
        case_id = record['case_id']
        rows.append(f'| {case_id} | {record["verdict"]} | [réponse]({case_id}/response.md) | [jugement]({case_id}/judgment.json) | [répondant]({case_id}/liaison/execution-repondant.json), [juge]({case_id}/liaison/execution-juge.json) |')
    rows.extend(['', 'Limite de preuve : le contenu des messages initiaux chiffrés n’est pas attesté (initial_message_verified=false). Les 28 questions figées sont attestées par une lecture outil complète après SKILL; les autres lectures observées se limitent aux 30 fichiers runtime autorisés.', '', 'Synthèse machine : [summary.json](summary.json). Notes détaillées des 28 juges : [rapport-28-cas.json](rapport-28-cas.json). Les jugements sont les écritures originales des juges; aucun score ancien transféré.'])
    _write(RUN / 'rapport-28-cas.md', '\n'.join(rows) + '\n')
    manifest['measurement_status'] = 'exécutée, 28 réponses et 28 jugements liés aux traces natives filtrées'
    (RUN / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(summary, ensure_ascii=False))

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=('prepare', 'export', 'bind-responder', 'bind-judge', 'summarize'))
    parser.add_argument('--case')
    parser.add_argument('--agent')
    args = parser.parse_args()
    if args.command == 'prepare': prepare()
    elif args.command == 'export': export(args.case)
    elif args.command == 'bind-responder': bind_responder(args.case, args.agent)
    elif args.command == 'bind-judge': bind_judge(args.case, args.agent)
    else: summarize()
