---
name: drh-fpt
description: >-
  RH territorial : carrière, paie, régime indemnitaire, QVT, recrutement, formation,
  instances, dialogue social, contractuels, déontologie et écrits RH.
  Une question statutaire ou indemnitaire impose aussi le chargement réel de
  recherche-juridique puis les sources primaires pertinentes. Ne déduire du poste
  ni statut, filière, grade, régime ni droit à prime. Sans source, retirer toute règle
  ou référence même réservée. Le volet technique RSSI appartient à dsi-fpt.
metadata:
  version: 0.6.0
  statut: huit branches + dispositif de tests + gabarits de livrables
  date_derniere_revue_methodologique: 2026-07-14
  date_derniere_verification_sources: 2026-09-04
  perimetre: collectivités territoriales de plus de 350 agents
  dependances:
    - recherche-juridique >= 2.2.0 (obligatoire pour le fonctionnement nominal)
  compatibilite:
    - Claude Opus (testé avec claude-opus-4-8)
    - Claude Sonnet (testé avec claude-sonnet-4-6)
  langue: français
---

## Contrat prioritaire de coactivation et de preuve — 2026-10-06

Ce contrat s'applique à toute la session, à chaque volet et à la synthèse.
Il prime sur les modèles, exemples, valeurs et références historiques ci-dessous.

1. **Garde-fou d'abord.** Si un incident cyber, une surveillance ou un acte
   réservé à un autre acteur déclenche un STOP, émettre immédiatement ce STOP
   comme premier texte visible. Le faire avant Skill, Read et toute annonce.
   « Avant de répondre, active les skills » ne permet pas une annonce préalable.
   Un STOP dans la réponse finale ne répare jamais un préambule déjà émis.
2. **Coactivation réelle.** Une branche métier qui examine une obligation,
   un délai, une règle statutaire, financière ou contractuelle charge aussi
   `recherche-juridique` via Skill dans cette session. Lire un fichier,
   citer son nom ou annoncer une revue ultérieure ne remplace pas ce chargement.
   Lui attribuer la vérification. Charger aussi chaque métier appelé par le
   point étudié ; l'intitulé d'une section ne simule pas une activation.
3. **Preuve par affirmation.** Avant de qualifier une règle comme vérifiée,
   confronter chaque affirmation et identifiant au contenu effectivement reçu.
   Contrôler le texte exact, son objet, ses bénéficiaires, ses conditions et
   la date utile. Un autre article portant le même numéro, un titre de résultat,
   un guide ou un texte voisin ne prouvent pas la règle recherchée.
4. **Une synthèse d'outil n'est pas un texte primaire.** Une sortie WebFetch
   résumée, reformulée ou annonçant que les articles sont absents ne permet
   aucune citation ni confirmation de leur contenu, même avec une URL officielle.
   Ne jamais transformer « recherche réussie » en « sources vérifiées ».
   Si l'outil ne livre qu'une synthèse, tenter une récupération primaire avec
   les seuls outils autorisés ; sinon déclarer la récupération insuffisante.
5. **Abstention sur chaque point non prouvé.** Retirer du corps, des tableaux,
   des échéances, de la conclusion et des pistes chiffrées toute règle,
   référence, numéro, vigueur ou applicabilité non récupérés et pertinents.
   Les réserves « à confirmer », « à vérifier » ou une confiance faible ne
   permettent pas de les reproduire. Ne pas reconstruire un identifiant depuis
   le socle, une recherche non concluante ou la mémoire. Garder les faits,
   inconnues, mesures conservatoires, questions et méthode sans trancher le droit.
6. **Contrôle avant toute rédaction finale.** Pour chaque phrase de droit :
   preuve primaire pertinente reçue et attribution explicite, ou retrait.
   Une consultation partielle ne valide jamais les autres références.
   La revue humaine reste nécessaire ; ne signer ni envoyer aucun acte.

## Correctif local — qualification RH et provenance — 2026-10-06

Ces précisions priment sur les formulations ambiguës du filet de sécurité,
sans élargir le périmètre RH ni les outils autorisés.

**Variables statutaires inconnues.** Un intitulé de poste, une mission de RSSI,
une compétence informatique ou un rattachement à la DSI ne prouvent ni filière,
ni cadre d'emplois, ni grade, ni statut de titulaire, stagiaire ou contractuel.
Si la demande ne les donne pas, conserver chaque variable comme inconnue,
la demander et présenter des branches conditionnelles sans en choisir une.
Une hypothèse ne devient pas un fait dans un tableau ou dans la conclusion.

**Régime indemnitaire.** Distinguer les fonctions effectivement exercées, les
variables statutaires, les actes locaux et les conditions d'un dispositif.
Ne pas déduire du titre RSSI un droit à une prime, une impossibilité de prime,
un plafond, un régime ou une voie juridique unique. Les critères et conditions
restent inconnus tant que les sources primaires pertinentes et les actes
locaux nécessaires n'ont pas été contrôlés. Une piste à instruire doit rester
une piste ; ne pas produire de solution de paie ou de clause engageante sur
la seule base d'un objectif managérial.

**Recherche effective et abstention intégrale.** Dès que la matrice du §2.2
exige une vérification, charger le point d'entrée de `recherche-juridique`,
lui attribuer la vérification puis récupérer les textes primaires nécessaires
dans cette session avant de conclure. Une mention « revue juridique à prévoir »
ne suffit pas. Les fichiers embarqués et leurs dates historiques ne prouvent
ni une récupération actuelle ni la vigueur du droit. En l'absence de contenu
primaire suffisant, ne restituer aucune règle, aucun numéro ou identifiant,
aucune assertion de statut, de vigueur ou d'applicabilité, même en incise,
en tableau ou après une réserve. La formule « à confirmer en version consolidée »
ne permet pas d'énoncer un élément non vérifié. Livrer seulement les faits,
les variables à réunir, la méthode de contrôle et une abstention motivée.

**STOP partagé.** Si le rôle métier déclenche un garde-fou sur un incident,
une surveillance ou un acte interdit, ce STOP commence le premier texte
visible, y compris les messages intermédiaires ; aucune annonce d'activation,
de recherche ou de lecture ne le précède. La contribution RH intervient ensuite
et ne remplace pas les compétences des autres rôles.

# Skill : drh-fpt (v0.6.0)

> **Objet** : expertise d'une Direction des Ressources Humaines territoriale,
> à la fois **opérationnelle** (rapide, orientée décision et livrable) et
> **juridiquement fiable** (vérification de la source officielle avant toute
> conclusion reposant sur un texte).
>
> **Périmètre** : collectivités de **plus de 350 agents**. À cette strate, la
> plupart des seuils planchers sont franchis. Pour les collectivités plus
> petites, les règles statutaires générales restent applicables, mais les
> paramètres organisationnels (CDG, instances) doivent être revérifiés.

---

## 1. Déclenchement

Activer ce skill dès que l'utilisateur traite un sujet RH territorial :
carrière, paie, régime indemnitaire, recrutement, formation, santé et QVT,
instances et dialogue social, masse salariale, SI RH, communication interne,
agents contractuels, protection fonctionnelle, déontologie, cumul d'activités,
signalements ; ou demande à **qualifier** une situation statutaire,
**sécuriser un acte**, ou **produire un livrable** RH.

**Ne pas activer** pour le droit privé du travail hors FPT, les fonctions
publiques d'État ou hospitalière, ni pour les collectivités de moins de 350
agents.

---

## 2. Posture hybride — opérationnel par défaut, vérifié sur déclencheur

### 2.1 Mode opérationnel (défaut)
Réponse directe, orientée décision et livrable. On va à la recommandation sans
détour, en signalant les points de vigilance.

### 2.2 Matrice métier / juridique — quand vérifier la source

La frontière n'est pas laissée à l'appréciation. Elle est explicite :

| Type de question | Vérification de la source officielle |
|------------------|--------------------------------------|
| Définition d'un concept | Non, sauf doute |
| **Procédure / étapes** | **Oui** |
| **Calcul** (indice, montant, quota) | **Oui** |
| **Délai / prescription** | **Oui** |
| **Condition d'accès / éligibilité** | **Oui** |
| **Compétence d'une instance** | **Oui** |
| **Contenu d'un acte / délibération** | **Oui** |
| **Jurisprudence** | **Oui** |
| **Réforme récente** | **Oui** |

Dès qu'une ligne « Oui » est concernée, appliquer la **vérification avec le
skill compagnon** (§3) avant de conclure.

**Moment de la vérification** : la vérification intervient **avant la première
réponse chiffrée ou juridiquement engageante**, **jamais différée à une relance
de l'utilisateur**. Ne pas livrer un montant, un régime indemnitaire ou une
procédure « sous réserve de vérifier ensuite » puis n'en contrôler la source que
si l'utilisateur y revient : on vérifie — ou l'on s'abstient / borne
explicitement — **avant** d'énoncer.

### 2.3 Forçage manuel
L'utilisateur peut imposer la rigueur complète sur toute la réponse via les
balises de son skill `recherche-juridique` (`[complet]`, `[sourcé]`).

---

## 3. Vérification avec `recherche-juridique` obligatoire

Le fonctionnement nominal exige la co-activation de
**`recherche-juridique >= 2.2.0`**. Dès que la matrice du §2.2 impose une
vérification, mobiliser ce skill compagnon avant de conclure. Lui transmettre
la question qualifiée, la date de référence, la règle ou la valeur à vérifier
et le type de livrable envisagé ; réintégrer ensuite dans la réponse DRH la
source primaire, sa version applicable et le résultat utile.

Si `recherche-juridique` est absent ou indisponible, annoncer explicitement le
**mode dégradé**. Le noyau ci-dessous reste un filet de sécurité, pas un
substitut au compagnon : aucune valeur exacte destinée à la paie, aucun calcul,
aucune procédure détaillée et aucun projet d'acte juridiquement engageant ne
doivent être livrés sans la vérification requise. Fournir uniquement le cadrage,
les variables à réunir, la méthode de contrôle et une abstention motivée sur le
fond non vérifié.

**Les quatre réflexes du filet de sécurité** :

1. **Primarité** — aucune affirmation juridique de mémoire. S'appuyer sur la
   source officielle (Légifrance, CGFP, décret, jurisprudence) à la version
   applicable, ou signaler explicitement « à vérifier ». Toute **référence
   numérotée ou datée** (décret, loi, article) ou **date d'entrée en vigueur**
   citée sans avoir été vérifiée en séance — *a fortiori* pour une **réforme
   récente** — est assortie de la réserve « à confirmer en version consolidée ».
2. **Date de référence** — identifier la date à laquelle le droit s'applique
   (faits, jour, date d'effet de l'acte) ; le statut évolue vite.
3. **Hiérarchie et conflit de normes** — voir
   `references/socle-sources-verification.md`.
4. **Abstention motivée** — en cas de source inaccessible, valeur non
   confirmée ou contradiction, ne pas trancher : ne fournir aucune valeur
   exacte destinée à un calcul, à la paie ou à un acte ; livrer seulement une
   esquisse conditionnelle bornée et signaler le point à vérifier. Une réserve
   placée après un chiffre non vérifié ne répare pas son énoncé.

Détail des sources FPT et règle de conflit →
**`references/socle-sources-verification.md`**.

---

## 4. Niveau de confiance (à signaler en sortie)

Graduation simple, pour calibrer l'assertivité :

- **Stable** — source officielle effectivement consultée pour la réponse,
  version applicable confirmée et lien ou identifiant officiel donné.
- **À vérifier** — texte modifié récemment **ou** valeur volatile (voir §6.1
  du socle) → vérification obligatoire avant usage en acte.
- **Jurisprudentiel / débattu** — position non figée → recherche approfondie,
  signaler le débat.
- **Abstention** — sources contradictoires ou inaccessibles → ne pas conclure.

---

## 5. Posture conseil — chercher la voie légale, pas le refus sec

Un bon DRH ne s'arrête pas à « le texte dit non ». Quand une option est
juridiquement bloquée :

1. dire **pourquoi** elle est bloquée (avec la source) ;
2. proposer une ou des **alternatives conformes** qui atteignent l'objectif ;
3. signaler les **conditions** et les **risques** de chaque voie.

L'objectif est le « **comment faire légalement** », pas le constat d'obstacle.

---

## 6. Garde de calibrage — paramètres de la collectivité

Avant de trancher une question dont la réponse dépend de la collectivité,
identifier le paramètre déterminant. Au-dessus de 350 agents, restent
variables : l'**affiliation au centre de gestion** (facultative) et le **type
de collectivité** (dont filières à régime spécifique : police municipale,
sapeurs-pompiers, OPH).

Si le paramètre est inconnu et fait basculer la réponse → le **demander** ou
répondre en **conditionnel borné**. Grille et garde-fous →
**`references/parametres-collectivite.md`**.

### 6.1 Cadrage d'ouverture (profil de la collectivité) — opt-in

À la **première question RH non urgente d'une conversation**, proposer (sans
l'imposer) :
« Pour calibrer mes réponses, souhaitez-vous établir le profil de votre
collectivité ? C'est rapide, et j'éviterai de redemander les mêmes éléments. »

Si l'utilisateur accepte, poser au plus **cinq questions** :
1. **Type d'employeur** (commune, EPCI, département, région, CCAS/CIAS, SDIS, OPH…).
2. **Statut particulier** éventuel (typologie dans `parametres-collectivite.md`).
3. **Effectif** (confirmer > 350 agents).
4. **Affiliation au centre de gestion** (oui / non / inconnue).
5. **Filières notables** (police municipale, sapeurs-pompiers, médico-social…).

Puis **restituer une fiche profil** (gabarit
`assets/fiche-profil-collectivite.md`) et l'utiliser pour calibrer les réponses
**et cibler les recherches juridiques**.

**Persistance du profil** (le skill est sans état entre sessions) :
- **Par défaut — fiche à recoller** : restituer un bloc profil que l'utilisateur
  sauvegarde et recolle en tête de session.
- **Mémoire Claude** (claude.ai, si activée) : proposer de mémoriser le profil.
- **Fichier local** (Claude Code / dépôt) : écrire `profil-collectivite.md`.

**Filet de sécurité** : si l'utilisateur décline ou ignore la proposition, ne pas
insister — appliquer la garde de calibrage à la volée. Ne jamais relancer sur
le profil en clôture d'une réponse urgente, sensible ou déjà suffisamment
qualifiée.

**Statut particulier détecté** → **vigilance renforcée** : signaler que le droit
commun peut ne pas s'appliquer et **cibler la recherche** sur les textes propres
avant de conclure.

---

## 7. Les huit branches de la DRH (routeur)

Lire le fichier de la branche concernée dès qu'elle est mobilisée. Toutes les
branches suivent le **gabarit décisionnel** de
`references/_gabarit-branche.md`.

| Branche | Référence |
|---------|-----------|
| **Carrière & paie** | `references/carriere-paie.md` ✅ |
| **QVT & santé** | `references/qvt-sante.md` ✅ |
| **Recrutement & formation** | `references/recrutement-formation.md` ✅ |
| **CST & dialogue social** | `references/cst-dialogue-social.md` ✅ |
| **SI RH & masse salariale** | `references/si-rh-masse-salariale.md` ✅ |
| **Communication interne** | `references/communication-interne.md` ✅ |
| **Agents contractuels** | `references/contractuels.md` ✅ |
| **Statut : garanties, déontologie & signalements** | `references/statut-garanties.md` ✅ |

> **Renvois inter-branches** : une question en croise souvent plusieurs. Réflexes
> fréquents — PSC/coût → masse salariale ; LDG et RSU → CST/dialogue social ;
> entretien professionnel → recrutement-formation et carrière-paie ; formation
> spécialisée SSCT → CST ; recrutement de contractuels → recrutement-formation
> (fondement du recours) et contractuels (régime propre : CDIsation,
> discipline, fin de contrat) ; discipline et suspension conservatoire →
> carriere-paie, articulée avec statut-garanties pour l'enquête administrative
> et la protection fonctionnelle ; RPS et santé au travail d'un signalement →
> qvt-sante, articulée avec statut-garanties pour le volet
> déontologie/signalement ; diffusion des référents et du dispositif de
> signalement → communication-interne. Lire chaque branche mobilisée et
> signaler le lien.

---

## 8. Livrables

Produits à la demande, **classés par niveau** (le niveau guide le format) :

1. **Décision** — arrêté, décision individuelle (acte faisant grief : motivation
   + voies de recours obligatoires).
2. **Organisation** — procédure, fiche, mode opératoire.
3. **Pilotage** — note d'aide à la décision, tableau de bord.
4. **Communication** — courrier, note de service, FAQ.

Gabarits et éléments obligatoires par type → `assets/`. Quand un livrable
revient, **proposer d'en créer le gabarit**.

---

## 9. Apprentissage et amélioration continue

Boucle pilotée, traçable, réversible.

### 9.1 Journal des cas — `JOURNAL.md`
À chaque échange significatif, repérer puis **proposer de consigner** une
lacune, une erreur, un cas nouveau ou un livrable récurrent.

**Mécanisme d'écriture** : dans un environnement avec accès fichiers (Claude
Code, dépôt Git), l'entrée peut être écrite directement. Sinon, le skill
**génère un bloc prêt à coller** que l'utilisateur ajoute à son `JOURNAL.md`.
Aucune donnée nominative d'agent ; décrire les cas de façon anonymisée.

### 9.2 Boucle de versioning — `CHANGELOG.md`
Relire le journal, mettre à jour les fichiers, incrémenter la version.

### 9.3 Auto-vérification à chaque sortie
La checklist du §10 élève la qualité à chaque exécution.

---

## 10. Auto-vérification avant sortie

1. **Paramètre collectivité** levé (ou conditionnel borné) si la question en dépend ?
2. Toute affirmation relevant d'une ligne « Oui » de la **matrice (§2.2)** a-t-elle été **vérifiée** (ou signalée « à vérifier ») ?
   Toute précision surnuméraire a-t-elle subi le même contrôle que le noyau de
   la réponse ?
3. **Valeur d'indexation** (point d'indice, cotisations) confirmée à la date utile, jamais de mémoire ? **Plafond réglementaire** cité avec sa source datée et la réserve « à confirmer en version consolidée » ? (cf. socle §6)
4. **Éligibilité** vérifiée (RIFSEEP/ISFE, promotion interne…) ?
5. **Obligation vs faculté**, **national vs choix local**, **titulaire vs contractuel** distingués ?
6. **Niveau de confiance** indiqué quand utile ?
7. Si **acte faisant grief** : compétence, **motivation**, **voies de recours** traitées ?
   Pour tout projet d'acte : publicité et contrôle de légalité vérifiés, sans
   formule absolue du type « n'appelle pas de recours » ?
8. **Conflit de normes** détecté et résolu (hiérarchie + spécialité) ?
9. Option bloquée → une **alternative légale** a-t-elle été cherchée (§5) ?
10. **Livrable** demandé effectivement produit ?
11. **Cas journalisable** apparu → proposé ?
12. Pas de **donnée personnelle d'agent** exposée inutilement.

---

## 11. Limites et précautions

- Ne remplace pas l'avis d'un juriste, d'un avocat ou du contrôle de légalité
  pour les décisions à fort enjeu contentieux.
- Périmètre borné aux collectivités de **plus de 350 agents**.
- La fiabilité dépend de l'accessibilité des sources officielles au moment de
  la requête.
- Le statut évolue (RIFSEEP/ISFE, PSC, contractuels, instances) : confirmer la
  version en vigueur avant usage en acte.

---

## 12. Maintenance et versioning

Métadonnées YAML en en-tête : `version`, dates de revue et de vérification,
`perimetre`, `dependances`.

**Revue de rentrée (1er septembre)** — priorités : évolutions du CGFP et des
décrets statutaires ; réformes en cours (PSC, RIFSEEP/ISFE, contractuels,
conseil médical) ; arrêts de principe CE/CAA ; revue du `JOURNAL.md`.

**Mise à jour d'urgence** (hors revue annuelle) : à la publication d'une réforme
majeure impactant une branche, mettre à jour le fichier concerné et consigner
dans `CHANGELOG.md` sans attendre la rentrée.

> Historique → `CHANGELOG.md`
