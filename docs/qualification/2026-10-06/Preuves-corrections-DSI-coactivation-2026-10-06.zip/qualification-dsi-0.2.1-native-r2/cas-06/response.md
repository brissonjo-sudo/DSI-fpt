Pour éviter la rupture, conditionnez la bascule à une **reprise démontrée des données et des opérations métier**, avec un retour arrière testé. Une promesse d’export de l’éditeur ne suffit pas. Votre service informatique est **internalisé** : il peut piloter la migration, mais la validation du service rendu reste à organiser avec le métier.

Je mobilise `dsi-fpt`, selon le routage de `references/analyse-situation.md`. Aucun incident ni besoin de surveillance n’est décrit. **[Risque : à préciser, élevé si le service est essentiel / Confiance : stable sur la méthode, à vérifier sur votre capacité réelle de reprise.]** Sans recette, je ne peux pas recommander une date de bascule.

### Plan de migration — [INCOMPLET]

Il manque le métier concerné, l’interruption et la perte de données acceptables, les interfaces, les possibilités d’export, les essais déjà réalisés et les documents contractuels. Le plan suivant est une proposition opérationnelle à compléter, sans calendrier inventé.

**1. Définir ce qui doit continuer à fonctionner.** Avec le responsable métier, recensez les opérations indispensables, les périodes sensibles, les utilisateurs et les conséquences d’une interruption. Cartographiez les données de référence, pièces jointes, statuts, configurations et interfaces entrantes et sortantes. Pour chaque dépendance, indiquez son responsable et l’effet de son indisponibilité. C’est le point de départ de `references/applications-interoperabilite.md`.

**2. Démontrer la sortie et la reprise avant de fixer la bascule.** Demandez un export d’essai documenté : formats, dictionnaire, relations entre données et éléments associés. Testez l’import dans un environnement distinct, avec des données fictives. Faites contrôler par le métier des dossiers et parcours représentatifs : liens conservés, statuts corrects, pièces lisibles, résultats attendus, absence de doublons et traitement des rejets. Le nombre de lignes importées ne prouve pas la reprise fonctionnelle. Si l’export n’est pas exploitable, reportez la bascule. Ces contrôles viennent de `references/applications-interoperabilite.md` ; l’inventaire de sortie et l’assistance technique à prévoir relèvent de `references/contrats-prestataires.md`.

**3. Préparer le fonctionnement dégradé et le retour arrière.** Faites définir par le métier l’interruption maximale acceptable, la perte de données acceptable et les opérations maintenues si la migration échoue. Préparez un mode dégradé utilisable par les agents et sa régularisation ultérieure. Testez le retour à l’ancien fonctionnement : restauration, accès, interfaces et reprise des opérations. Une sauvegarde réalisée n’est pas une restauration démontrée (`references/securite-si.md`). Les objectifs métier et l’ordre de reprise suivent `references/crise-cyber-continuite.md` ; aucune durée générique ne remplace ces arbitrages.

**4. Organiser les modifications entre export et bascule.** Choisissez une migration progressive si les lots et leurs dépendances le permettent, sinon une bascule coordonnée. Définissez une source faisant autorité pour chaque donnée. Prévoyez une suspension contrôlée des écritures ou une reprise des modifications intervenues depuis l’export. Évitez deux applications qui modifient les mêmes données sans règle de rapprochement. Le retour arrière doit aussi traiter les opérations saisies dans le nouveau logiciel : rouvrir l’ancien seul pourrait les perdre (`references/applications-interoperabilite.md`).

**5. Répéter la bascule complète.** Éprouvez l’import, les interfaces, les droits, les accès techniques, les performances nécessaires au métier et le retour arrière. Formez les agents aux opérations essentielles et au canal d’assistance. Préparez une organisation à confirmer : pilote DSI interne, validateur métier, intervenants des deux éditeurs, remplaçants et décideur de bascule à identifier selon les délégations vérifiées (`objets/projet-si.md`). Bornez les accès prestataires au besoin et prévoyez leur retrait contrôlé (`references/securite-si.md`).

**6. Décider sur preuves, puis surveiller le service.** Constituez un dossier de décision avec résultats d’essais, anomalies, corrections, validations métier, conditions d’arrêt et possibilité de retour. Après bascule, contrôlez les opérations réellement effectuées, les flux et les rejets ; attribuez chaque anomalie à un responsable. Conservez l’ancien fonctionnement disponible selon les conditions à confirmer, jusqu’à recette et décision tracée de retrait. Ne fermez pas prématurément ses accès ou interfaces utiles (`references/applications-interoperabilite.md`).

### Conditions proposées pour autoriser la bascule

| Condition | Preuve attendue |
|---|---|
| Données reprises et cohérentes | Rapprochements et validation de dossiers représentatifs par le métier |
| Parcours essentiels et interfaces utilisables | Recette fonctionnelle, contrôles des échanges et des rejets |
| Reprise possible en cas d’échec | Essai de restauration et de retour, avec traitement des nouvelles saisies |
| Exploitation prête | Agents formés, assistance disponible, responsables identifiés |
| Écarts maîtrisés | Aucun écart bloquant ; réserves et décision explicitement tracées |

Un échec d’import, une incohérence métier majeure, une interface indispensable inutilisable ou un retour non démontré justifie de différer la bascule. Cette grille est une exigence technique proposée, pas une clause déjà opposable aux éditeurs (`references/contrats-prestataires.md`).

### Points qui restent à vérifier séparément

**Volet relevant de `recherche-juridique` : non activable ici.** Aucun texte primaire ni contrat n’a été récupéré dans cette session. Je ne confirme donc aucun droit de restitution, frais, préavis, prolongation de maintenance ou obligation d’assistance. Faites instruire ces points à partir du contrat et de ses annexes par l’interlocuteur juridique ou contractuel, avec vérification des sources applicables. Le rôle de `recherche-juridique` est de vérifier ce fond ; la DSI conserve l’inventaire et les contrôles techniques (`references/contrats-prestataires.md`).

Si le logiciel traite des données personnelles : **BASCULE dpo-ct — Cette question porte sur le droit des données personnelles. Je ne la tranche pas ici. À reprendre côté dpo-ct : exigences de protection applicables à la migration.** La DSI mettra en œuvre les mesures reçues avant de valider les choix techniques.

Pour compléter le plan, précisez d’abord le service métier concerné et l’interruption qu’il peut accepter, sans donnée nominative ni secret. Une fois la migration éprouvée, un retour d’expérience anonymisé pourra être proposé pour `JOURNAL.md`, conformément à `SKILL.md`.
