Je vous recommande de proposer au DGS **un mandat écrit de pilotage de la sécurité**, avec du temps identifié, un circuit d’arbitrage et un contrôle indépendant lorsque vous participez aussi à l’exploitation. Le titre de RSSI, seul, ne précise ni les moyens ni les décisions que vous pourrez prendre.

Votre mode d’exercice est **internalisé**. Aucun incident ni demande de surveillance n’est décrit ; le cadrage relève de la prévention, selon `references/analyse-situation.md`.

Les propositions ci-dessous sont des **bonnes pratiques d’organisation à faire confirmer**, pas des conclusions sur vos pouvoirs juridiques. Aucun texte primaire n’a été récupéré dans cette session et `recherche-juridique` n’a pas pu être activé. Je ne confirme donc ni une obligation de désigner un RSSI, ni une délégation, ni l’identité du signataire compétent. Ces points relèvent de `recherche-juridique`, avec les actes locaux et les textes officiels à consulter sur Légifrance, conformément à `references/socle-sources-verification.md`.

**Le rôle à proposer**

Selon `references/gouvernance-strategie.md`, définissez votre fonction par ses résultats : analyser les risques, proposer les exigences de sécurité, alerter, suivre les écarts et vérifier l’efficacité des mesures. L’organisation suivante constitue une proposition à valider :

| Acteur | Contribution proposée |
|---|---|
| Vous, dans la fonction RSSI | Présenter les risques, les options, les preuves et les écarts ; organiser le suivi et l’escalade. |
| Service informatique | Mettre en œuvre et exploiter les mesures ; documenter et tester leur fonctionnement. |
| Responsables métiers | Définir les services essentiels, les conséquences d’une interruption et les conditions de reprise acceptables. |
| DGS | Organiser les arbitrages et porter les décisions vers le décideur compétent, dont les pouvoirs restent à vérifier. |
| DPO | Fournir ses exigences sur son périmètre avant les choix de mesures ; conserver son rôle distinct de la conduite technique. |

**Si vous cumulez RSSI et exploitation**, identifiez explicitement ce cumul. Prévoyez un regard indépendant pour les points sensibles : relecture par une compétence extérieure ou un pair qualifié, et examen des écarts par le circuit de gouvernance. Évitez de présenter votre propre réalisation comme une preuve suffisante de son efficacité. Le circuit d’alerte doit vous permettre de signaler un risque même lorsqu’il résulte d’un choix du service informatique (`references/gouvernance-strategie.md`).

**Les premiers arbitrages à demander au DGS**

1. **Le périmètre et les priorités métier.** Quels services protéger en premier ? Pour chacun, documenter les conséquences d’une perte de disponibilité ou de données et les dépendances nécessaires à la reprise.
2. **La capacité réelle.** Quel temps consacrer à la mission, quelles tâches concurrentes différer, quelle formation et quel appui technique mobiliser ? Ajouter les besoins de remplacement en cas d’absence.
3. **Le circuit de décision.** Qui instruit, qui exécute, qui contrôle et qui décide d’un risque restant ouvert ? Faire vérifier les compétences et délégations avant de formaliser ce dernier rôle.
4. **Le traitement des exceptions.** Pour chaque mesure différée : justification, effet sur le service, compensation possible, responsable et condition de réexamen. Une absence de réponse ne constitue pas une décision d’acceptation.
5. **Les preuves attendues.** Définir dès le départ comment démontrer qu’une action fonctionne, plutôt que compter uniquement les actions annoncées comme terminées.

Ces arbitrages suivent `references/gouvernance-strategie.md` et `references/securite-si.md`. Présentez les besoins en charge et en moyens, avec leurs dépendances, avant toute décision financière.

**Commencer par un socle court et vérifiable**

Selon `references/securite-si.md`, partez des services à maintenir, puis rapprochez inventaire, accès, maintenance et sauvegardes. Les priorités proposées sont à ajuster au diagnostic :

| Priorité | Travail initial | Preuve recherchée |
|---|---|---|
| Reprise | Vérifier ce qui est sauvegardé, la protection des copies et les dépendances nécessaires. | Résultat d’une restauration autorisée, validée fonctionnellement par le métier. |
| Accès sensibles | Examiner les accès distants et privilégiés, la séparation administration/usages ordinaires et les accès prestataires. | Validation des droits et contrôle des protections ; aucun retrait sans examen des dépendances. |
| Maintenance | Identifier les composants exposés, les mises à jour et les éléments non maintenables. | État de maintenance documenté, action attribuée et possibilité de retour à un état de service. |
| Règles communes | Construire une PSSI courte : périmètre, accès, protection, contrôle, exceptions et réexamen. | Règles réalisables par l’équipe et plan d’actions avec responsables. |

Recueillez les exigences des métiers et du DPO avant de choisir les mesures. Pour chaque action, consignez **risque → mesure → responsable → dépendances → preuve → écart restant**. Si la capacité manque, soumettez un choix explicite : traiter, différer avec compensation, simplifier ou abandonner une demande concurrente.

**Le support concret pour votre entretien**

Préparez une note de mandat marquée **[INCOMPLET — proposition à valider]**, avec : périmètre connu, résultats attendus, temps et appuis demandés, articulation avec l’exploitation, contrôle indépendant, circuit d’escalade, premières priorités et décisions attendues. Les inconnues sont notamment votre fonction actuelle, la capacité de l’équipe, les services essentiels, l’état des sauvegardes et les délégations existantes. Ce format de pilotage provient de `references/gouvernance-strategie.md` ; il n’est pas présenté comme un acte juridiquement validé.

Retenez quelques indicateurs qui permettent une décision : services essentiels avec reprise démontrée, écarts critiques ouverts, dépendances non maîtrisées et actions bloquées faute de moyens. Évitez les indicateurs individuels.

BASCULE drh-fpt — La formalisation de votre emploi et les éventuelles conséquences statutaires relèvent de ce skill et de la DRH. Je ne les tranche pas ici.

BASCULE dirfi-fpt — L’inscription budgétaire et le financement des moyens relèvent de ce skill et du service des finances. Je ne les tranche pas ici.

Le cadrage préventif relève de **[moyen / stable]** ; la protection des accès privilégiés et la reprise de services essentiels restent **[élevé / à vérifier]** tant que les preuves ne sont pas réunies. Vous pouvez ainsi porter l’analyse et le suivi, avec des moyens et des arbitrages visibles, sans accepter implicitement tous les risques du SI.
