Je mobilise `dsi-fpt` pour le cadrage opérationnel. Avec un service informatique interne, le bon point de départ est une **mission écrite, un circuit d’arbitrage et du temps réservé**. Évitez une fonction RSSI réduite à un titre ajouté à l’exploitation quotidienne.

Le mode est **internalisé**. Aucun incident ni demande de surveillance n’est décrit ; je traite donc une organisation préventive, selon `references/analyse-situation.md`.

**Cadrer la mission avec le DGS**

Selon `references/gouvernance-strategie.md`, définir le rôle par ses résultats : analyser les risques, proposer les exigences de sécurité, alerter, suivre les écarts et contrôler l’efficacité des mesures. Voici une répartition proposée, à faire confirmer ; elle ne vaut ni délégation ni attribution juridique de compétence.

| Acteur | Contribution opérationnelle proposée |
|---|---|
| Vous, au titre du RSSI | Tenir le diagnostic et le plan de traitement ; présenter les options, les preuves et les risques restant ouverts ; disposer d’un accès direct au circuit d’arbitrage |
| Service informatique | Déployer et exploiter les mesures ; documenter leur fonctionnement et produire les résultats des essais |
| Responsables métiers | Identifier les services essentiels, les conséquences d’une interruption et valider les essais fonctionnels |
| DGS | Organiser les arbitrages, examiner les besoins et porter les décisions auprès du décideur dont les pouvoirs auront été vérifiés |
| DPO | Fournir ses exigences sur son périmètre avant le choix des mesures ; la conduite technique reste côté SI |

Si vous exploitez aussi le SI, **rendez le cumul explicite**. Prévoir un regard indépendant sur les mesures les plus sensibles, par exemple une revue technique par un autre intervenant compétent. Une mesure que vous avez déployée ne devrait pas être déclarée efficace sur votre seule appréciation. Préciser qui vous remplace et à qui vous signalez un désaccord ou un risque non traité (`references/gouvernance-strategie.md`).

**Les premiers arbitrages**

Partir des services à maintenir, puis des composants techniques. Selon `references/securite-si.md`, instruire en priorité :

1. **La reprise réelle** : quelles données, configurations et dépendances faut-il récupérer ? Existe-t-il une copie protégée d’une compromission commune et une restauration effectivement démontrée sur un périmètre autorisé ? Une sauvegarde annoncée comme réussie ne suffit pas.
2. **Les accès sensibles** : séparation des usages ordinaires et de l’administration, protection des accès distants et privilégiés, accès des prestataires bornés et comptes techniques dotés d’un responsable. Vérifier les dépendances avant tout retrait.
3. **La maintenance** : équipements et applications exposés, maintenance disponible, écarts connus et capacité de retour au service après une mise à jour.
4. **La capacité d’exécution** : retenir peu d’actions réalisables, avec un responsable, une charge estimée et une preuve attendue. Différer les projets concurrents qui empêcheraient de traiter un risque prioritaire.

Pour chaque arbitrage, présenter **le service concerné, le scénario redouté, les faits établis, les options, les besoins, le risque résiduel et la décision attendue**. Faire tracer toute exception avec sa justification, les compensations et son point de réexamen ; un silence ne constitue pas une décision (`references/securite-si.md`).

**Brouillon de note à soumettre au DGS — [INCOMPLET]**

> Objet : cadrer une fonction RSSI dans un SI internalisé.
>
> Mission proposée : rendre les risques visibles, proposer un socle de sécurité exploitable, suivre les actions et en contrôler les résultats.
>
> Arbitrages demandés : périmètre couvert ; temps réservé ; accès aux informations nécessaires ; circuit d’alerte ; intervenant chargé du regard indépendant ; premiers services à protéger ; actions à engager et projets à différer.
>
> Livrables proposés : inventaire utile aux services essentiels, registre des risques et exceptions, PSSI courte, plan d’actions attribué et tableau de suivi limité aux décisions utiles.
>
> Champs manquants : votre fonction actuelle, l’effectif et la capacité disponibles, les services prioritaires, les preuves de restauration, le décideur habilité et le circuit de validation.

Ce format de pilotage vient de `references/gouvernance-strategie.md` ; il n’est pas présenté comme un contenu légal obligatoire.

**Points à vérifier séparément**

BASCULE drh-fpt — Le statut, les conditions d’attribution de cette fonction et ses éventuelles conséquences sur votre emploi relèvent du volet RH. Je ne les tranche pas ici.

Pour les pouvoirs du signataire, une éventuelle délégation et les obligations de désignation ou de sécurité applicables à votre commune, le volet compétent est `recherche-juridique`. Il n’a pas pu être activé dans ce dossier et **aucun texte primaire n’a été récupéré dans cette session** : aucune conclusion juridique sur ces points. Les actes locaux et les textes officiels seront à examiner via Légifrance, avec l’appui du service juridique, selon `references/socle-sources-verification.md`.

**[moyen / stable]** pour ce cadrage préventif ; les décisions concernant un service essentiel ou des accès privilégiés demandent des preuves complémentaires. Pour ajuster la note, les trois informations les plus utiles sont votre rôle actuel, le temps réellement disponible et les services dont l’interruption serait la plus dommageable. Un retour d’expérience anonymisé pourra ensuite être proposé pour `JOURNAL.md`.
