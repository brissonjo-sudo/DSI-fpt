Vous pouvez préparer une architecture **par zones de confiance**, avec une matrice des échanges autorisés et un dossier d’exploitation conservé dans vos circuits internes. La gestion est **internalisée** : la proposition doit rester administrable par votre équipe, y compris lorsqu’un intervenant est absent.

**[Risque élevé / confiance à vérifier]** pour une modification commune à plusieurs écoles : la méthode est utilisable, mais votre séparation actuelle, vos dépendances et votre capacité de reprise ne sont pas vérifiées. Le cadrage suit `references/analyse-situation.md` ; aucun incident ni demande de surveillance de personnes n’est décrit.

### 1. Partir des usages et des responsabilités

Pour chaque école, établir une fiche anonymisée : familles d’utilisateurs, services indispensables, équipements partagés, responsable fonctionnel, exploitant et conséquence d’une coupure. Ne pas supposer que tous les équipements de l’école relèvent de votre équipe : confirmer les frontières avec les partenaires concernés, notamment pour les services pédagogiques. Cette démarche vient de `objets/site-reseau.md` et de `references/infrastructures-reseaux.md`.

Décrire ici les besoins par catégories, sans nom d’école, compte réel, adresse réseau, configuration ou plan existant.

### 2. Séparer les zones et justifier les échanges

Le modèle fonctionnel suivant est une proposition à adapter, pas une description de votre réseau (`references/infrastructures-reseaux.md`) :

| Zone | Usage | Principe de séparation |
|---|---|---|
| Administratif | Services administratifs autorisés | Accès aux seuls services nécessaires ; pas d’accès depuis les invités |
| Pédagogique | Enseignement, terminaux et ressources pédagogiques | Échanges limités aux ressources validées ; pas de circulation générale vers l’administratif |
| Invités | Accès temporaire ou appareils non maîtrisés | Accès Internet selon le besoin ; exclusion des ressources internes et des interfaces d’administration |
| Équipements partagés | Impression et autres équipements communs | Accès depuis les seules familles d’usage qui en ont besoin ; pas de pont général entre zones |
| Administration technique | Gestion des équipements et services | Accès réservé aux fonctions habilitées, distinct des usages ordinaires |

Appliquer également ce raisonnement entre écoles : un besoin commun ne justifie pas une communication générale entre tous les sites. Documenter chaque exception.

Des noms de réseaux ou des VLAN distincts ne prouvent pas l’isolement. La séparation dépend aussi du contrôle effectif des échanges, des droits et des chemins alternatifs. Éviter les exceptions trop larges pour résoudre une difficulté d’impression ou d’accès à une ressource.

Préparer une **matrice de flux abstraite** : zone d’origine, famille de service destinataire, besoin métier, sens de l’échange, responsable de validation, critère de test. Les paramètres réels seront définis et conservés localement par les personnes habilitées.

### 3. Prévoir l’exploitation dès la conception

Selon `references/securite-si.md`, séparer les accès ordinaires des accès privilégiés, limiter les droits au besoin, attribuer les comptes techniques et prévoir le remplacement de l’administrateur habituel. Organiser la maintenance, la sauvegarde des configurations et une restauration éprouvée dans un périmètre autorisé.

Selon `references/infrastructures-reseaux.md`, associer chaque service à ses dépendances : liaison, identité, résolution de noms, énergie, équipements centraux et moyens de maintenance. Prévoir des indicateurs de disponibilité et de capacité, un destinataire des alertes et un circuit d’intervention. Ce suivi porte sur l’état des services ; il ne constitue pas une autorisation d’observer l’activité de personnes.

Pour la continuité (`references/crise-cyber-continuite.md`), faire définir par les responsables des usages ce qui doit rester possible lors d’une coupure et dans quel ordre reprendre. Une seconde liaison partageant la même panne, ou une alimentation de secours non testée, ne démontre pas une continuité.

### 4. Préparer un dossier sans divulgation

Le **dossier de site — brouillon [INCOMPLET]**, fondé sur `objets/site-reseau.md`, peut contenir :

- une vue fonctionnelle anonymisée des zones et services ;
- la matrice des échanges nécessaires ;
- les responsabilités d’exploitation et de validation ;
- les dépendances, scénarios de panne et modes dégradés ;
- le plan de modification, les critères de réception et de retour à l’état précédent ;
- les réserves, responsables de traitement et preuves attendues.

La version partageable reste abstraite. La documentation opérationnelle détaillée reste dans un espace interne à accès restreint, avec diffusion maîtrisée. Ne joignez ici ni export de configuration, ni plan d’adressage, ni interface d’administration identifiable. Les secrets restent dans leur dispositif de gestion dédié, jamais dans le dossier. Cette séparation respecte `SKILL.md` §6 et `references/infrastructures-reseaux.md`.

### 5. Migrer et réceptionner par étapes

Commencer par un site pilote représentatif, avec intervention autorisée, état initial récupérable et critères d’arrêt. Vérifier les usages nécessaires **et** les échanges qui doivent être bloqués, avec des essais contrôlés dans votre périmètre. Tester ensuite le mode dégradé et le retour au fonctionnement normal. Consigner les résultats et réserves avant d’étendre aux autres sites (`references/infrastructures-reseaux.md`).

Les champs encore manquants sont : diversité des écoles, familles de services, frontières d’exploitation, équipements partagés, dépendances centrales, capacité de maintenance et fonctionnement dégradé attendu. Vous pouvez les renseigner sous forme anonymisée ; aucun détail sensible n’est nécessaire pour poursuivre le cadrage.

Ces éléments sont des recommandations techniques. Aucun texte primaire ni contrôle de votre infrastructure n’a été obtenu dans cette session : ils ne constituent ni une conclusion juridique, ni une validation de sécurité de votre réseau.
