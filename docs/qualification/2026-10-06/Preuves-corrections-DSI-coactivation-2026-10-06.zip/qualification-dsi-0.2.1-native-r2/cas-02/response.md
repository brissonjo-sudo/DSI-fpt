Votre première PSSI doit fixer **les services à protéger, les règles minimales, les responsabilités et les preuves de leur application**. En mutualisation, conservez dans la collectivité le pilotage des priorités et des risques ; demandez au service commun de proposer puis d’exécuter un socle réalisable, avec des résultats contrôlables.

J’utilise `dsi-fpt`. Le mode d’exercice est bien **mutualisé**, conformément au cadrage de `references/analyse-situation.md`. Aucun incident ni demande de surveillance n’est décrit. Les propositions suivantes sont opérationnelles : **aucun texte primaire n’a été récupéré dans cette session**. Je ne confirme donc ni compétence juridique, ni délégation, ni obligation réglementaire, ni contenu légalement obligatoire de la PSSI.

**Ce que la collectivité doit arbitrer dans l’organisation proposée** — repères de `references/gouvernance-strategie.md`, à confronter à la convention et aux délégations :

- Le périmètre : services, sites, applications et équipements couverts par la PSSI ; éléments gérés par le service commun et éléments restant ailleurs.
- Les services essentiels et les conséquences acceptables d’une interruption ou d’une perte de données. Les responsables métiers décrivent leurs besoins de reprise ; le service commun explique ce qui est techniquement atteignable.
- Le circuit de décision : qui porte le besoin métier, qui instruit le risque, qui exécute, qui contrôle et qui peut accepter un risque résiduel. Le service commun ne doit pas accepter implicitement un risque pour la collectivité.
- Les priorités et les moyens d’exploitation : retenir des mesures que les équipes peuvent administrer, contrôler et maintenir, avec un remplaçant identifié.
- Les exceptions : justification, mesure compensatoire, responsable, preuve attendue et condition de réexamen. Un écart non traité reste visible ; l’absence de réponse n’est pas une acceptation.

La matrice de travail peut associer un porteur local sous pilotage de la DGS, les métiers, une fonction RSSI pour l’analyse et le contrôle, et le service commun pour l’exploitation. **Cette répartition est une proposition à confirmer, pas une désignation juridique du décideur.** Prévoir un regard distinct de l’exploitant pour apprécier les résultats, ou documenter le contrôle compensatoire si les moyens imposent un cumul.

**Ce qu’il faut demander au service commun** — socle proposé par `references/securite-si.md` :

| Sujet | Demande concrète | Preuve à examiner avec la collectivité |
|---|---|---|
| Périmètre et dépendances | Inventaire exploitable des services, applications, équipements, dépendances et responsables ; liste des exclusions | Inventaire daté, écarts et dépendances critiques identifiés |
| Comptes et accès | Circuit de validation métier, droits minimaux, séparation des usages ordinaires et d’administration, maîtrise des comptes techniques et des accès prestataires | Matrice des rôles, procédure et résultats de revue anonymisés ; écarts suivis |
| Accès sensibles | Plan de protection des accès distants et privilégiés, dont authentification renforcée selon le risque | État de couverture, exceptions et résultats de contrôle sans secrets |
| Maintenance | Plan de mises à jour priorisé par exposition et criticité ; traitement des composants non maintenables | État de maintenance, écarts, actions et possibilités de retour au service |
| Sauvegardes | Périmètre incluant données, configurations et dépendances ; copies protégées d’une compromission commune ; séparation des accès d’administration | Compte rendu de restauration autorisée, résultat fonctionnel et écarts ; un succès de sauvegarde seul ne suffit pas |
| Alerte et reprise | Contacts fonctionnels et remplaçants, circuit d’escalade, articulation entre service commun, collectivité et métiers | Procédure connue des parties et exercice de vérification du circuit |
| Contrôle et documentation | Tableau des mesures réalisées, risques ouverts, preuves manquantes et décisions attendues | Dossier accessible à la collectivité par un canal adapté, sans données nominatives inutiles ni architecture exploitable dans les documents diffusés |

Recueillez **les exigences du DPO et des métiers avant de choisir et valider les mesures**. La DSI et le service commun traduisent ces exigences en protections techniques ; cette réponse ne qualifie pas la conformité des traitements.

Pour les engagements de service, `references/contrats-prestataires.md` recommande de distinguer ce qui est **déjà convenu**, ce qui est **constaté** et ce qui est **nouvellement demandé**. Demandez la convention et ses annexes : périmètre, exclusions, interlocuteurs, prestations de sécurité, accès et documentation conservés, contrôle et modalités techniques de sortie. Pour chaque engagement proposé, préciser l’objet mesuré, la plage de service, la méthode de mesure, les exclusions et le traitement des écarts. Séparer prise en charge, contournement, rétablissement et résolution ; ne fixer aucun délai arbitraire. Une demande nouvelle ne devient pas un engagement existant par sa seule inscription dans la PSSI.

**Brouillon de première PSSI — [INCOMPLET]**, selon `references/securite-si.md` :

1. Objectifs, périmètre et services essentiels.
2. Organisation du pilotage, responsabilités proposées et escalade.
3. Règles de gestion des accès, protection des postes et maintenance.
4. Sauvegardes, restauration et exigences métier de reprise.
5. Alerte, contrôle, preuves et sensibilisation des utilisateurs.
6. Gestion des exceptions, suivi des écarts et réexamen après changement important.

Joignez un plan d’actions comportant, pour chaque ligne : **service concerné → scénario de risque → action → responsable → dépendances → preuve → risque restant → arbitrage attendu**. Commencez par les écarts qui exposent l’administration ou rendent la reprise impossible. Mesurez ensuite quelques résultats utiles : couverture des protections prioritaires, maintenance, restaurations démontrées et écarts non clos.

Le brouillon reste incomplet tant que manquent la convention, les délégations, la liste des services essentiels, l’inventaire, l’état des protections, les preuves de restauration et la capacité du service commun. Demandez ces pièces sous forme abstraite ou anonymisée, sans identifiants de connexion ni secrets.

Selon `references/socle-sources-verification.md`, le rôle de **`recherche-juridique`** serait de confirmer le régime de mutualisation, les pouvoirs du décideur et les éventuelles exigences applicables au périmètre. Ce skill n’a pas pu être activé dans le dossier fourni et aucune source primaire n’est disponible : ces points restent en abstention. Les vérifications sont à conduire sur Légifrance pour les textes et sur les portails officiels concernés pour les référentiels, en parallèle de la lecture de la convention ; les fichiers internes ne constituent pas une preuve actuelle.

**[Risque élevé / confiance à vérifier]** pour les accès privilégiés et la reprise des services essentiels, faute de preuves d’exécution. Vous pouvez lancer immédiatement l’inventaire, la collecte des pièces et la préparation des arbitrages ; la validation de la PSSI doit s’appuyer sur les résultats contrôlés et sur un circuit de décision confirmé.
