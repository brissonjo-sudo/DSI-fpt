Commencez par une **PSSI courte, adaptée aux services à maintenir**, accompagnée d’une matrice des responsabilités et d’un plan d’actions vérifiable. En informatique mutualisée, le service commun prépare et exploite les mesures ; la collectivité conserve le pilotage de ses besoins, de ses priorités et des risques à arbitrer. Cette organisation est une proposition à confronter à votre convention, aux compétences et aux délégations effectives (`references/gouvernance-strategie.md`).

Le mode mutualisé est identifié ; la demande porte sur la prévention, sans incident ni surveillance décrits (`references/analyse-situation.md`). **[Risque moyen / confiance stable]** pour la méthode ; **[risque élevé / confiance à vérifier]** pour la protection et la reprise des services essentiels tant que les preuves manquent.

**Les décisions à préparer côté collectivité**, selon `references/securite-si.md` :

| Décision proposée | Ce qu’il faut obtenir avant arbitrage |
|---|---|
| Délimiter le périmètre de la PSSI | Services, sites, applications, équipements et dépendances couverts ; exclusions explicites, y compris ceux hors service commun |
| Prioriser les services essentiels | Conséquences d’une indisponibilité, d’une perte ou d’une altération ; fonctionnement dégradé et reprise acceptables, validés par les métiers |
| Organiser les rôles | Pour chaque action : décideur à confirmer, responsable métier, exécutant technique et contrôleur ; correspondant local et interlocuteur sécurité du service commun |
| Retenir un socle réalisable | Mesures, charge d’exploitation, responsables suppléants et moyens nécessaires ; exigences du DPO recueillies avant le choix et la validation des mesures |
| Traiter les exceptions | Risque restant, justification, mesure compensatoire, responsable, décision explicite et condition de réexamen ; aucun écart accepté par silence |
| Définir le suivi | Preuves attendues, revue des écarts et déclencheurs de réexamen après un changement important |

La fonction sécurité peut instruire les risques et contrôler les résultats. Le service commun ne devrait pas accepter seul les risques de votre collectivité. Si exploitation et contrôle sont assurés par les mêmes personnes, prévoyez un regard indépendant et un circuit d’escalade (`references/gouvernance-strategie.md`).

**Demandez au service commun un dossier de départ contrôlable**, plutôt qu’une simple déclaration de sécurité (`references/securite-si.md`) :

- **Convention et périmètre de service** : prestations couvertes, exclusions, responsabilités proposées, contacts, escalades, accès conservés et modalités techniques de sortie.
- **État initial** : inventaire utilisable, propriétaires métiers, dépendances critiques, équipements ou logiciels non maintenus et écarts connus.
- **Accès** : procédure d’habilitation et de retrait, séparation des comptes ordinaires et d’administration, protection des accès distants et privilégiés, encadrement des accès prestataires ; bilan de contrôle sans données nominatives.
- **Maintenance** : suivi des correctifs selon exposition et criticité, traitement des composants non maintenables et capacité de retour à un état de service.
- **Sauvegarde et reprise** : périmètre réellement récupérable, configurations et dépendances incluses, protection des copies contre une compromission commune, séparation des accès d’administration et compte rendu d’une restauration autorisée avec validation métier. Une sauvegarde exécutée ne démontre pas une reprise réussie.
- **Alerte et contrôle** : circuit d’alerte, relais en cas d’absence, traçabilité des opérations dans un cadre autorisé, gestion des écarts et tableau de bord agrégé. La présence de journaux n’autorise pas l’accès aux traces d’une personne.
- **Plan d’amélioration** : pour chaque risque, action, responsable, dépendances, preuve attendue et arbitrage sur le risque résiduel.

Formalisez les engagements proposés en précisant l’objet mesuré, les plages de service, les exclusions et la méthode de constat. Distinguez prise en charge, contournement, rétablissement et résolution. Les objectifs et échéances sont à convenir selon les besoins et la capacité réelle ; aucune valeur n’est présumée. Une nouvelle exigence n’est pas un engagement déjà souscrit (`references/contrats-prestataires.md`).

Votre première PSSI peut reprendre cette trame opérationnelle : **périmètre ; responsabilités ; accès ; protection et maintenance ; sauvegarde et reprise ; usages et alerte ; contrôles ; exceptions ; réexamen**. Joignez un tableau « risque → action → responsable → preuve → décision restante ». Ces rubriques sont des choix de pilotage, sans qualification de contenu légal obligatoire (`references/securite-si.md`).

Pour lancer le travail, réunissez le correspondant local, le service commun et les responsables métiers : validez les services prioritaires, confrontez les pièces disponibles aux preuves attendues, puis soumettez les écarts et options au décideur identifié. Testez aussi le partage des responsabilités sur des scénarios fictifs de panne, de demande d’accès et de fin de service (`references/gouvernance-strategie.md`).

**Limite de vérification : aucun texte primaire n’a été récupéré dans cette session.** Le point d’entrée de `recherche-juridique` n’est pas disponible dans les fichiers fournis ; ce rôle n’a donc pas été activé. Je ne confirme ni le régime juridique de votre service commun, ni le signataire compétent, ni les obligations réglementaires applicables. Ce volet doit vérifier la catégorie de groupement, la convention, les compétences et délégations, ainsi que les exigences de sécurité applicables aux systèmes concernés, à partir de Légifrance et des sources officielles pertinentes (`references/socle-sources-verification.md`).

Pour adapter cette base, les pièces manquantes sont la convention, le périmètre confié, les services essentiels, les interlocuteurs sécurité et les derniers résultats de restauration. Fournissez seulement des éléments abstraits ou anonymisés, sans secret ni architecture exploitable. Un retour d’expérience anonymisé sur la construction de cette PSSI pourra ensuite être proposé pour `JOURNAL.md`, sans écriture automatique.
