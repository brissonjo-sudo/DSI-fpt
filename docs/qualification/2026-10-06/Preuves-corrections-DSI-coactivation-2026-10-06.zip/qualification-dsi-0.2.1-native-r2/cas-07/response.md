**Je recommande de prendre en charge le courriel dans votre circuit de réception, sans décider de l'écarter sur la seule présence d'un portail.** C'est une précaution opérationnelle ; je ne peux pas confirmer ici si ce courriel constitue une saisine valable, ni si le portail peut être imposé pour cette démarche.

J'applique `dsi-fpt`, branche `references/dematerialisation-teleservices.md` : préserver la réception, orienter vers le service métier et éviter de perdre la demande pendant l'examen du canal utilisé.

Concrètement :

1. Conserver le message reçu, ses pièces et les éléments de réception dans le circuit autorisé, sans modifier la date constatée.
2. Transmettre la demande au service compétent et identifier qui prend en charge son examen.
3. Éviter une réponse automatique qui rejette le courriel ou exige un nouveau dépôt avant cet examen. Si un dépôt sur le portail est ensuite retenu, prévoir le rapprochement des deux transmissions pour éviter les doublons.
4. Donner à l'usager un retour factuel, par exemple : « Nous avons reçu votre courriel et le transmettons au service chargé de votre démarche. Celui-ci vous précisera les modalités de prise en charge. » Ce message ne doit pas être présenté comme un accusé répondant à des exigences juridiques vérifiées.

Pour décider du traitement juridique, réunir : la nature exacte de la démarche, la collectivité et le service destinataires, la date de réception, l'adresse utilisée, l'existence d'un téléservice dédié à cette démarche et l'information effectivement portée à la connaissance du public.

**[Risque élevé / confiance : abstention sur le droit]** Aucun texte primaire n'a été récupéré dans cette session. `recherche-juridique` ne peut pas être réellement activé avec les fichiers disponibles ; je ne simule donc pas sa conclusion. Selon `references/socle-sources-verification.md`, son volet devra vérifier sur Légifrance les règles de saisine électronique, les éventuelles exceptions propres à la démarche, l'effet du canal dédié et les exigences de réponse ou d'accusé, ainsi que leurs conséquences sur les délais. Aucun délai ni fondement juridique n'est affirmé ici.
