Préparez deux dossiers liés : une reprise techniquement démontrée sous pilotage DSI, et un examen contractuel attribué à recherche-juridique puis au service juridique. À ce stade, je recommande de préparer les constats et une demande d’explications, sans adresser de mise en demeure ni annoncer une sanction.

**Cadrage — 07/10/2026.** Scénario fictif ; dates du contrat, de l’export et de sortie inconnues. Champ territorial et titulaire du contrat à préciser. Régime juridique non déterminé ; note express de préparation, mode A standard. Faits fournis : un export est proposé et jugé inexploitable par l’équipe informatique ; les pièces contractuelles ne sont pas examinées. Ce jugement technique reste à documenter ; aucun manquement contractuel n’est établi ici.

Les questions à lever avant de figer une option sont :

- Quelle entité a signé, quelles sont les dates pertinentes, et quelles pièces définissent la sortie et la restitution ?
- Qui exploite le SI — équipe interne, service mutualisé ou prestataire — et qui assurera la reprise et son support ?
- Quels tests échouent précisément, quelles données et fonctions sont concernées, et quel service serait interrompu ?

**Volet DSI : préparer et vérifier la reprise.** Le cadrage suit `dsi-fpt/references/analyse-situation.md` ; les éléments de sortie suivent `dsi-fpt/references/contrats-prestataires.md`.

1. **Conserver les constats.** Garder l’export reçu dans son état initial, sa date, sa version, les échanges et une copie de travail distincte. Constituer une chronologie factuelle avec erreurs reproductibles et conséquences métier, sans joindre de données nominatives ni de secrets au dossier de circulation.
2. **Inventorier le périmètre.** Lister données, relations entre tables, identifiants, pièces jointes, statuts, configurations, formats, encodages et dictionnaire des champs. Relever les interfaces, composants tiers, dépendances de licence et documents manquants. Distinguer éléments remis, éléments absents et éléments dont l’usage après sortie reste à examiner.
3. **Transformer “inexploitable” en écarts mesurables.** Pour chaque anomalie : résultat attendu proposé par le métier, résultat observé, méthode de test, preuve et responsable de correction. Ne pas présenter un besoin technique nouveau comme un engagement déjà souscrit.
4. **Tester la reprise.** Dans un environnement distinct et autorisé, utiliser d’abord un jeu fictif : importer, rapprocher les volumes, vérifier les relations et pièces, puis exécuter des opérations métier représentatives. Un fichier lisible ou un nombre de lignes concordant ne suffit pas à démontrer une reprise fonctionnelle. Le responsable métier, à désigner, valide les résultats ; la DSI documente les contrôles (`dsi-fpt/references/applications-interoperabilite.md`).
5. **Préparer l’exploitation et la continuité.** Identifier le responsable d’exploitation, l’assistance disponible, la supervision et le traitement des anomalies. Décrire le fonctionnement dégradé possible, les modifications intervenant entre export et bascule, les critères d’arrêt et le retour arrière. Conserver les accès encore autorisés utiles à la reprise ; toute prolongation est une question à examiner, pas un droit présumé. La décision de bascule reste à attribuer et à tracer après recette métier.

Le livrable technique est un **plan de sortie [INCOMPLET]**, accompagné d’un inventaire et d’un tableau : élément attendu / élément reçu / test / anomalie / impact / responsable / validation attendue. Le fournisseur est invité, par l’interlocuteur contractuel désigné, à expliquer les écarts et proposer un export documenté avec assistance et nouveau test. Aucun délai contractuel n’est inventé.

**Analyse recherche-juridique : droits et suites non confirmés.** Les fichiers méthodologiques ont été lus et appliqués ; cela ne constitue pas une activation native d’un Skill ou d’un plugin. Une recherche réelle a été menée le 07/10/2026 via droit_francais : deux recherches de jurisprudence judiciaire, puis une récupération de décision. Les résultats de recherche ne constituent pas une preuve du fond ; le retour de décision reçu est tronqué. Aucun texte primaire complet et pertinent ne permet ici de confirmer les droits du scénario. Je m’abstiens donc sur l’obligation de restitution, les frais, les droits de réutilisation, les pénalités, la résiliation et les conditions d’une mise en demeure. Les recherches judiciaires ne déterminent pas le régime ni la juridiction du contrat.

Pour l’examen humain, réunir contrat signé, annexes techniques, conditions générales et particulières, modifications, commandes, documents de recette, correspondances et factures. Faire examiner les questions suivantes :

- Quels engagements décrivent le périmètre, le format, la documentation, l’assistance et le résultat de la restitution ? Quels documents de référence sont effectivement intégrés et quelles dérogations existent ?
- Quels droits couvrent les données, configurations, logiciels et composants tiers après sortie, et quels frais sont documentés ?
- Quels écarts du dossier technique correspondent à ces engagements ? Quelle réponse apporter aux explications du fournisseur ?
- Quelles suites sont envisageables, avec quels fondements, preuves, interlocuteur habilité, formes et échéances ? Ces points restent à vérifier sur les pièces et les sources primaires applicables aux dates utiles.

Avant toute mise en demeure, faire valider le dossier d’écarts, le plan de continuité et une note juridique explicitant les points confirmés et les points ouverts. Un éventuel projet d’acte restera soumis à cette revue et à la décision de l’acteur habilité ; aucun acte n’est rédigé comme définitif, signé ou envoyé ici.

**Limites :** préparation technique possible ; reprise non testée ; examen contractuel non réalisé ; confiance juridique en abstention. Module CONTENTIEUX mobilisé pour repérer les questions à instruire, sans conclusion procédurale ; autres modules non mobilisés. Aucun autre rôle métier n’est chargé : si les pièces révèlent un volet de données personnelles ou de financement, son examen devra être attribué au rôle compétent avant de le traiter. Aucune source informelle utilisée. Méthode : `recherche-juridique/references/modules.md` et `recherche-juridique/references/gabarits-sortie.md`.
